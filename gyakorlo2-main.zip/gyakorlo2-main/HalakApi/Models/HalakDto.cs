﻿namespace HalakApi.Models
{
    public class HalakDto
    {
        public string Faj { get; set; } = null!;
        public decimal MeretCm { get; set; }
        public string Helyszin { get; set; } = null!;

    }
}
